package com.company.day011_for_iloop;

import java.util.Scanner;

public class For016 {
	public static void main(String[] args) {
		int kor, eng, math, tot = 0;
		float avg = 0f;
		String stdid = "", scholar = "장학생X", pass = "재시험", level = "";
		String gradek = "(가)", gradee = "(가)", gradem = "(가)";

		Scanner scanner = new Scanner(System.in);
		System.out.print("이름 입력 > ");
		stdid = scanner.next();
		for (;;) {
			System.out.print("국어점수입력 : ");
			kor = scanner.nextInt();
			if (kor >= 0 && kor <= 100) {
				break;
			}
		}
		for (;;) {
			System.out.print("영어점수입력 : ");
			eng = scanner.nextInt();
			if (eng >= 0 && eng <= 100) {
				break;
			}
		}
		for (;;) {
			System.out.print("수학점수입력 : ");
			math = scanner.nextInt();
			if (math >= 0 && math <= 100) {
				break;
			}
		}

		tot = kor + eng + math;
		avg = tot / 3.0f;
		if (avg >= 95) {
			scholar = "장학생O";
		}
		// 레벨
		if (avg == 100) {
			level = "**********";
		} else if (avg >= 90) {
			level = "*********";
		} else if (avg >= 80) {
			level = "********";
		} else if (avg >= 70) {
			level = "*******";
		} else if (avg >= 60) {
			level = "******";
		} else if (avg >= 50) {
			level = "*****";
		} else if (avg >= 40) {
			level = "****";
		} else if (avg >= 30) {
			level = "***";
		} else if (avg >= 20) {
			level = "**";
		} else if (avg >= 10) {
			level = "*";
		} else {
			level = "X";
		}
		// 합격여부
		if (avg >= 70 && (kor > 40 || eng > 40 || math > 40)) {
			pass = "합격";
		} else if (avg < 70) {
			pass = "불합격";
		}
		if (kor >= 90) {
			gradek = "(수)";
		} else if (kor >= 80) {
			gradek = "(우)";
		} else if (kor >= 70) {
			gradek = "(미)";
		} else if (kor >= 60) {
			gradek = "(양)";
		}
		if (eng >= 90) {
			gradee = "(수)";
		} else if (eng >= 80) {
			gradee = "(우)";
		} else if (eng >= 70) {
			gradee = "(미)";
		} else if (eng >= 60) {
			gradee = "(양)";
		}
		if (math >= 90) {
			gradem = "(수)";
		} else if (math >= 80) {
			gradem = "(우)";
		} else if (math >= 70) {
			gradem = "(미)";
		} else if (math >= 60) {
			gradem = "(양)";
		}
		
		String avgS = String.format("%.2f", avg);

		System.out.println("================================================================================");
		System.out.println("이름\t" + "국어\t" + "영어\t" + "수학\t" + "총점\t" + "평균\t\t" + "합격여부\t" + "장학생\t" + "레벨");
		System.out.println("================================================================================");

		System.out.println(stdid + "\t" + kor + gradek + "\t" + eng + gradee + "\t" + math + gradem + "\t" + tot + "\t"
				+ avgS + "\t\t" + pass + "\t" + scholar + "\t" + level);

	}

}
